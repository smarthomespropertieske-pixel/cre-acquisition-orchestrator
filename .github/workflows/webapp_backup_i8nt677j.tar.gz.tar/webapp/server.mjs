/**
 * easyTenancy — Production-grade static SPA server
 * Zero host restrictions, SPA fallback, correct MIME types, compression headers
 * Also handles /api/metrics/live and /api/og natively (no wrangler auth needed)
 * Replaces `vite preview` which enforces allowedHosts even with config overrides
 */
import http from 'http'
import fs from 'fs'
import path from 'path'
import zlib from 'zlib'
import { fileURLToPath } from 'url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const DIST = path.join(__dirname, 'dist')
const PORT = parseInt(process.env.PORT || '3000', 10)

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js':   'application/javascript; charset=utf-8',
  '.mjs':  'application/javascript; charset=utf-8',
  '.css':  'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png':  'image/png',
  '.jpg':  'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif':  'image/gif',
  '.svg':  'image/svg+xml',
  '.ico':  'image/x-icon',
  '.woff': 'font/woff',
  '.woff2':'font/woff2',
  '.ttf':  'font/ttf',
  '.eot':  'application/vnd.ms-fontobject',
  '.map':  'application/json',
  '.txt':  'text/plain',
  '.xml':  'application/xml',
  '.webp': 'image/webp',
}

// ── Deterministic metrics (mirrors functions/api/[[route]].ts) ───────────────
function buildMetrics() {
  const epoch = Math.floor(Date.now() / 100_000_000)
  return {
    totalManagers:  52_400 + epoch,
    roiMultiplier:  405,
    activeUnits:    892_000 + epoch * 12,
    leases:         2_400_000 + epoch * 40,
    complianceRate: 100,
    countries:      120,
    timestamp:      new Date().toISOString(),
  }
}

// ── Dynamic branded SVG OG image ────────────────────────────────────────────
const ACCENT = {
  UK: '#3b82f6', AE: '#f59e0b', KE: '#10b981',
  US: '#6366f1', AU: '#06b6d4', ZA: '#f97316', DEFAULT: '#39bff6',
}

function buildOGSvg(country = 'DEFAULT', title = 'easyTenancy', units = '') {
  const accent = ACCENT[country.toUpperCase()] ?? ACCENT.DEFAULT
  const m = buildMetrics()
  const subtitle = units
    ? `${units} units · ${country} · ${m.complianceRate}% compliant`
    : `${m.totalManagers.toLocaleString()} managers · ${country} · ${m.complianceRate}% compliant`

  return `<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="630" viewBox="0 0 1200 630">
  <defs>
    <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#0a0f1e"/>
      <stop offset="100%" style="stop-color:#0d1528"/>
    </linearGradient>
    <linearGradient id="accent" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" style="stop-color:${accent}"/>
      <stop offset="100%" style="stop-color:#6366f1"/>
    </linearGradient>
  </defs>
  <rect width="1200" height="630" fill="url(#bg)"/>
  <rect x="0" y="0" width="6" height="630" fill="url(#accent)"/>
  <rect x="0" y="580" width="1200" height="2" fill="${accent}" opacity="0.3"/>

  <!-- Brand -->
  <text x="60" y="80" font-family="system-ui,sans-serif" font-size="22" font-weight="900"
    fill="${accent}" letter-spacing="1">easyTenancy</text>
  <text x="60" y="108" font-family="system-ui,sans-serif" font-size="14"
    fill="rgba(255,255,255,0.35)">#1 PropTech 2025 · 120 jurisdictions</text>

  <!-- Title -->
  <text x="60" y="290" font-family="system-ui,sans-serif" font-size="56" font-weight="900"
    fill="white" letter-spacing="-1">${title.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}</text>
  <text x="60" y="350" font-family="system-ui,sans-serif" font-size="24"
    fill="rgba(255,255,255,0.55)">${subtitle}</text>

  <!-- Metric pills -->
  <rect x="60" y="420" width="200" height="50" rx="10" fill="${accent}" opacity="0.15"
    stroke="${accent}" stroke-width="1" stroke-opacity="0.4"/>
  <text x="160" y="449" font-family="system-ui,sans-serif" font-size="20" font-weight="700"
    fill="${accent}" text-anchor="middle">${(m.totalManagers/1000).toFixed(0)}K+ Managers</text>

  <rect x="278" y="420" width="180" height="50" rx="10" fill="#10b981" opacity="0.15"
    stroke="#10b981" stroke-width="1" stroke-opacity="0.4"/>
  <text x="368" y="449" font-family="system-ui,sans-serif" font-size="20" font-weight="700"
    fill="#10b981" text-anchor="middle">100% Compliant</text>

  <rect x="476" y="420" width="180" height="50" rx="10" fill="#a78bfa" opacity="0.15"
    stroke="#a78bfa" stroke-width="1" stroke-opacity="0.4"/>
  <text x="566" y="449" font-family="system-ui,sans-serif" font-size="20" font-weight="700"
    fill="#a78bfa" text-anchor="middle">${m.roiMultiplier}× ROI</text>

  <!-- Country badge -->
  <rect x="1060" y="50" width="100" height="40" rx="8" fill="${accent}" opacity="0.2"
    stroke="${accent}" stroke-width="1" stroke-opacity="0.5"/>
  <text x="1110" y="75" font-family="system-ui,sans-serif" font-size="18" font-weight="700"
    fill="${accent}" text-anchor="middle">${country.toUpperCase()}</text>
</svg>`
}

// ── JSON response helper ─────────────────────────────────────────────────────
function jsonRes(res, data, status = 200, extraHeaders = {}) {
  const body = JSON.stringify(data)
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Access-Control-Allow-Origin': '*',
    ...extraHeaders,
  })
  res.end(body)
}

// ── Static file helper (with gzip compression) ──────────────────────────────
function serveFile(req, res, filePath, statusCode = 200) {
  try {
    const data = fs.readFileSync(filePath)
    const ext  = path.extname(filePath).toLowerCase()
    const mime = MIME[ext] || 'application/octet-stream'
    const isAsset = filePath.includes('/assets/')
    const acceptsGzip = (req.headers['accept-encoding'] || '').includes('gzip')
    const compressible = ['.js', '.css', '.html', '.json', '.svg', '.txt', '.xml'].includes(ext)

    if (acceptsGzip && compressible && data.byteLength > 1024) {
      zlib.gzip(data, (err, compressed) => {
        if (err) { res.writeHead(500); return res.end() }
        res.writeHead(statusCode, {
          'Content-Type':     mime,
          'Content-Encoding': 'gzip',
          'Content-Length':   compressed.byteLength,
          'Cache-Control':    isAsset ? 'public, max-age=31536000, immutable' : 'no-cache, no-store, must-revalidate',
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Methods': 'GET, HEAD, OPTIONS',
          'X-Content-Type-Options': 'nosniff',
          'Vary': 'Accept-Encoding',
        })
        res.end(compressed)
      })
    } else {
      res.writeHead(statusCode, {
        'Content-Type':  mime,
        'Content-Length': data.byteLength,
        'Cache-Control': isAsset ? 'public, max-age=31536000, immutable' : 'no-cache, no-store, must-revalidate',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, HEAD, OPTIONS',
        'X-Content-Type-Options': 'nosniff',
      })
      res.end(data)
    }
  } catch {
    // SPA fallback
    const index = fs.readFileSync(path.join(DIST, 'index.html'))
    zlib.gzip(index, (err, compressed) => {
      const acceptsGzip = (req.headers['accept-encoding'] || '').includes('gzip')
      if (!err && acceptsGzip) {
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Content-Encoding': 'gzip', 'Content-Length': compressed.byteLength, 'Cache-Control': 'no-cache', 'Access-Control-Allow-Origin': '*' })
        res.end(compressed)
      } else {
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-cache', 'Access-Control-Allow-Origin': '*' })
        res.end(index)
      }
    })
  }
}

// ── Body reader ──────────────────────────────────────────────────────────────
function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = []
    req.on('data', c => chunks.push(c))
    req.on('end', () => {
      try { resolve(JSON.parse(Buffer.concat(chunks).toString() || '{}')) }
      catch { resolve({}) }
    })
    req.on('error', reject)
  })
}

// ── Main server ──────────────────────────────────────────────────────────────
const server = http.createServer(async (req, res) => {
  // CORS preflight
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin':  '*',
      'Access-Control-Allow-Methods': 'GET, POST, HEAD, OPTIONS',
      'Access-Control-Allow-Headers': '*',
    })
    return res.end()
  }

  const [urlPath, qs] = (req.url || '/').split('?')
  const params = new URLSearchParams(qs || '')

  // ── API routes ─────────────────────────────────────────────────────────────

  // GET /api/metrics/live — deterministic real-time stats
  if (req.method === 'GET' && urlPath === '/api/metrics/live') {
    return jsonRes(res, buildMetrics(), 200, {
      'Cache-Control': 'public, s-maxage=60, stale-while-revalidate=120',
    })
  }

  // GET /api/og — dynamic branded SVG
  if (req.method === 'GET' && urlPath === '/api/og') {
    const svg = buildOGSvg(
      params.get('country') ?? 'DEFAULT',
      params.get('title')   ?? 'easyTenancy',
      params.get('units')   ?? '',
    )
    res.writeHead(200, {
      'Content-Type': 'image/svg+xml',
      'Cache-Control': 'public, s-maxage=3600',
      'Access-Control-Allow-Origin': '*',
    })
    return res.end(svg)
  }

  // GET /api/ai/models — model list (sandbox stub)
  if (req.method === 'GET' && urlPath === '/api/ai/models') {
    return jsonRes(res, {
      ok: true,
      models: ['@cf/meta/llama-3.1-8b-instruct'],
      note: 'Sandbox stub — Workers AI active on Cloudflare Pages',
    })
  }

  // POST /api/ai/* — Gemini proxy + Workers AI fallback
  if (req.method === 'POST' && urlPath.startsWith('/api/ai/')) {
    const body = await readBody(req)
    const mode = urlPath.split('/').pop()

    // ── Gemini proxy (if GEMINI_API_KEY is set) ──────────────────────────────
    const GEMINI_KEY = process.env.GEMINI_API_KEY
    const reqModel   = body.model ?? 'gemini-2.0-flash'

    if (GEMINI_KEY && (mode === 'chat' || mode === 'retention-email')) {
      try {
        const sysPrompt = [
          'You are the easyTenancy AI Copilot — a world-class property management expert.',
          'You have deep knowledge of: UK (Section 21, EPC C 2028), UAE (RERA, Ejari), Kenya (KES tax, M-Pesa, ODPC), US (Fair Housing), Australia (RTA), South Africa (POPIA).',
          'Be concise, data-driven, and always cite the relevant regulation when applicable.',
          body.context ? `Context:\n${body.context}` : '',
        ].filter(Boolean).join('\n\n')

        const geminiRes = await fetch(
          `https://generativelanguage.googleapis.com/v1beta/models/${reqModel}:generateContent?key=${GEMINI_KEY}`,
          {
            method:  'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              contents: [{ role: 'user', parts: [{ text: body.message ?? '' }] }],
              systemInstruction: { parts: [{ text: sysPrompt }] },
              generationConfig: {
                temperature:     0.7,
                maxOutputTokens: 1024,
                topP:            0.95,
              },
            }),
          }
        )

        if (geminiRes.ok) {
          const gData = await geminiRes.json()
          const text  = gData?.candidates?.[0]?.content?.parts?.[0]?.text ?? ''
          const usage = gData?.usageMetadata ?? {}
          return jsonRes(res, {
            ok:          true,
            response:    text,
            model:       reqModel,
            tokensUsed:  usage.totalTokenCount ?? Math.ceil(text.length / 4),
            source:      'gemini',
            traceId:     body.traceId,
            proposalId:  body.proposalId,
          })
        }
      } catch (err) {
        console.error('[server] Gemini error:', err?.message ?? err)
        // Fall through to stub
      }
    }

    // ── Smart sandbox stubs (model-aware) ────────────────────────────────────
    const modelLabel = reqModel.includes('pro') ? 'Gemini 2.5 Pro' : 'Gemini 2.0 Flash'
    const countryHint = body.context?.match(/units in (\w+)/)?.[1] ?? 'Global'
    const stubs = {
      chat: `[${modelLabel} · ${countryHint}] ${body.message ? `Re: "${body.message.slice(0, 60)}" — ` : ''}The AI Copilot is fully wired to the Global Orchestrator. Set GEMINI_API_KEY in .env.local to activate live Gemini responses. In production (Cloudflare Pages), the edge function calls Gemini 2.5 Pro directly with your portfolio context, jurisdiction rules, and spatial data from the Maps API.`,
      'retention-email': `[${modelLabel}] Retention email draft ready. Configure GEMINI_API_KEY to generate personalised proposals with 2026 market-adjusted lease terms, Einstein score context, and jurisdiction-specific compliance language.`,
      describe:  `[${modelLabel}] Property description AI active on CF Pages. Deploy with GEMINI_API_KEY to generate professional letting descriptions.`,
      summarize: `[${modelLabel}] Portfolio executive summary pending. Activate with GEMINI_API_KEY for Gemini-powered insights.`,
    }
    return jsonRes(res, {
      ok:         true,
      response:   stubs[mode] ?? stubs.chat,
      model:      reqModel,
      tokensUsed: 0,
      source:     'stub',
      sandbox:    true,
      traceId:    body.traceId,
    })
  }

  // POST /api/orchestrator/event — receive Orchestrator events from CF Workers
  if (req.method === 'POST' && urlPath === '/api/orchestrator/event') {
    const event = await readBody(req)
    console.log(`[Orchestrator] ${event.type} ← ${event.source} (${event.traceId})`)
    return jsonRes(res, { ok: true, received: true, ts: Date.now() })
  }

  // GET /api/compliance/jurisdiction — IP→regime detection
  if (req.method === 'GET' && urlPath === '/api/compliance/jurisdiction') {
    const country = (params.get('country') ?? req.headers['cf-ipcountry'] ?? 'US').toUpperCase()
    const REGIMES = {
      GB:'GDPR',DE:'GDPR',FR:'GDPR',IT:'GDPR',NL:'GDPR',SE:'GDPR',
      US:'CCPA', KE:'KES', TH:'PDPA', SG:'PDPA', ZA:'POPIA',
    }
    const regime = REGIMES[country] ?? 'generic'
    return jsonRes(res, {
      ok: true,
      country,
      regime,
      gdprApplies:  regime === 'GDPR',
      taxReporting: ['KE','ZA','NG'].includes(country),
      ts: new Date().toISOString(),
    })
  }

  // ─── TinyFish v4.3 — server-side search + intel proxy ────────────────────
  // GET /api/search?q=...
  if (req.method === 'GET' && urlPath === '/api/search') {
    const key = process.env.TINYFISH_API_KEY
    const q    = (params.get('q')    ?? '').trim()
    const loc  = params.get('loc')   ?? 'US'
    const lang = params.get('lang')  ?? 'en'
    if (!key) return jsonRes(res, { ok: false, error: 'search_unconfigured', results: [] }, 503)
    if (!q || q.length < 2)   return jsonRes(res, { ok: false, error: 'query_too_short', results: [] }, 400)
    if (q.length > 200)        return jsonRes(res, { ok: false, error: 'query_too_long',  results: [] }, 400)
    try {
      const u = new URL('https://api.search.tinyfish.ai')
      u.searchParams.set('query',    q)
      u.searchParams.set('location', loc)
      u.searchParams.set('language', lang)
      const r = await fetch(u.toString(), { headers: { 'X-API-Key': key } })
      if (!r.ok) {
        const text = await r.text().catch(() => '')
        return jsonRes(res, { ok: false, error: `tinyfish ${r.status}`, detail: text.slice(0, 200), results: [] }, 502)
      }
      const data = await r.json()
      return jsonRes(res, {
        ok: true,
        query:   data.query,
        results: (data.results ?? []).slice(0, 8).map((x) => ({
          title:   x.title,
          url:     x.url,
          snippet: x.snippet,
          source:  x.site_name,
        })),
      }, 200, { 'Cache-Control': 'public, s-maxage=300' })
    } catch (err) {
      return jsonRes(res, { ok: false, error: err.message, results: [] }, 502)
    }
  }

  // GET /api/intel/proptech — Competitor Intelligence feed
  if (req.method === 'GET' && urlPath === '/api/intel/proptech') {
    const key = process.env.TINYFISH_API_KEY
    const STUB = [
      { title: 'AI-driven property management market projected to reach $19.4B by 2030', url: 'https://www.grandviewresearch.com/industry-analysis/proptech-market', source: 'grandviewresearch.com', summary: 'PropTech CAGR of 14.8% driven by AI leasing + predictive maintenance.' },
      { title: 'Yardi launches Voyager 8 with embedded LLM assistant',                    url: 'https://www.yardi.com/news',                                              source: 'yardi.com',              summary: 'Generative AI for compliance docs and rent-roll analysis to enterprise.' },
      { title: 'AppFolio acquires AI screening startup for $340M',                        url: 'https://www.appfolio.com/about/news',                                     source: 'appfolio.com',           summary: 'Automated tenant screening and predictive churn scoring.' },
      { title: 'UAE RERA opens beta for blockchain-anchored Ejari contracts',             url: 'https://dubailand.gov.ae',                                                source: 'dubailand.gov.ae',       summary: 'Tamper-proof lease registry pilot with 18 PropTech partners.' },
      { title: 'EU AI Act compliance becomes mandatory for property platforms',           url: 'https://digital-strategy.ec.europa.eu',                                   source: 'digital-strategy.ec.europa.eu', summary: 'Algorithmic transparency required for tenant scoring + dynamic pricing.' },
      { title: 'JLL invests in AI valuation startup, partners with global PropTech',      url: 'https://www.jll.com/news',                                                source: 'jll.com',                summary: 'Series C round values automated CRE valuation at $1.2B.' },
    ]
    if (!key) return jsonRes(res, { ok: true, source: 'stub', items: STUB }, 200, { 'Cache-Control': 'public, s-maxage=120' })
    try {
      const queries = ['PropTech AI funding announcement 2026', 'real estate AI platform launch global expansion']
      const results = await Promise.all(queries.map(async (q) => {
        const u = new URL('https://api.search.tinyfish.ai')
        u.searchParams.set('query', q); u.searchParams.set('location', 'US'); u.searchParams.set('language', 'en')
        const r = await fetch(u.toString(), { headers: { 'X-API-Key': key } })
        if (!r.ok) return { results: [] }
        return r.json()
      }))
      const seen = new Set()
      const items = []
      for (const data of results) {
        for (const x of (data.results ?? [])) {
          if (seen.has(x.url)) continue
          seen.add(x.url)
          items.push({ title: x.title, url: x.url, source: x.site_name, summary: x.snippet })
          if (items.length >= 8) break
        }
        if (items.length >= 8) break
      }
      const payload = items.length > 0
        ? { ok: true, source: 'live',  items }
        : { ok: true, source: 'stub',  items: STUB }
      return jsonRes(res, payload, 200, { 'Cache-Control': 'public, s-maxage=600' })
    } catch (err) {
      return jsonRes(res, { ok: true, source: 'stub', items: STUB, warn: err.message }, 200)
    }
  }

  // GET /api/arr — live ARR growth curve value
  if (req.method === 'GET' && urlPath === '/api/arr') {
    const TARGET   = 1_345_000_000
    const MIDPOINT = 24
    const STEEPNESS = 0.22
    const month    = new Date().getMonth()
    const L        = 1 / (1 + Math.exp(-STEEPNESS * (month - MIDPOINT)))
    const arr      = Math.floor(TARGET * L)
    return jsonRes(res, {
      ok: true,
      arrUSD: arr,
      target: TARGET,
      pct:    ((arr / TARGET) * 100).toFixed(2),
      ts:     new Date().toISOString(),
    }, 200, { 'Cache-Control': 'public, s-maxage=15' })
  }

  // ── Static file serving ────────────────────────────────────────────────────
  const cleanPath = urlPath.split('#')[0]
  const filePath  = path.join(DIST, cleanPath)

  // Security: prevent path traversal outside dist
  if (!filePath.startsWith(DIST)) {
    res.writeHead(403); return res.end('Forbidden')
  }

  // Exact file match
  if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
    return serveFile(req, res, filePath)
  }

  // Directory index
  const indexPath = path.join(filePath, 'index.html')
  if (fs.existsSync(indexPath)) {
    return serveFile(req, res, indexPath)
  }

  // SPA fallback — React Router handles all unknown paths
  serveFile(req, res, path.join(DIST, 'index.html'))
})

server.listen(PORT, '0.0.0.0', () => {
  console.log(`\n🚀 easyTenancy SPA server running`)
  console.log(`   Local:   http://localhost:${PORT}`)
  console.log(`   Network: http://0.0.0.0:${PORT}`)
  console.log(`   Dist:    ${DIST}`)
  console.log(`   API:     /api/metrics/live  /api/og  /api/ai/*  /api/arr  /api/compliance/jurisdiction`)
  console.log(`   No host restrictions — all tunnel URLs allowed\n`)
})

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error(`Port ${PORT} already in use. Run: fuser -k ${PORT}/tcp`)
    process.exit(1)
  }
  throw err
})
